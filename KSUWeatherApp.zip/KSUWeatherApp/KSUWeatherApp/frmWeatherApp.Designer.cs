﻿namespace KSUWeatherApp
{
    partial class frmWeatherApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPicnic = new System.Windows.Forms.Button();
            this.btnVacation = new System.Windows.Forms.Button();
            this.txtVacNum = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnPicnic
            // 
            this.btnPicnic.Location = new System.Drawing.Point(505, 93);
            this.btnPicnic.Name = "btnPicnic";
            this.btnPicnic.Size = new System.Drawing.Size(146, 26);
            this.btnPicnic.TabIndex = 0;
            this.btnPicnic.Text = "Best Day for Picnic";
            this.btnPicnic.UseVisualStyleBackColor = true;
            this.btnPicnic.Click += new System.EventHandler(this.btnPicnic_Click);
            // 
            // btnVacation
            // 
            this.btnVacation.Location = new System.Drawing.Point(505, 191);
            this.btnVacation.Name = "btnVacation";
            this.btnVacation.Size = new System.Drawing.Size(149, 23);
            this.btnVacation.TabIndex = 1;
            this.btnVacation.Text = "Days for Vaction";
            this.btnVacation.UseVisualStyleBackColor = true;
            this.btnVacation.Click += new System.EventHandler(this.btnVacation_Click);
            // 
            // txtVacNum
            // 
            this.txtVacNum.Location = new System.Drawing.Point(505, 154);
            this.txtVacNum.Name = "txtVacNum";
            this.txtVacNum.Size = new System.Drawing.Size(100, 20);
            this.txtVacNum.TabIndex = 2;
            // 
            // frmWeatherApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtVacNum);
            this.Controls.Add(this.btnVacation);
            this.Controls.Add(this.btnPicnic);
            this.Name = "frmWeatherApp";
            this.Text = "Kent State Weather Appo Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPicnic;
        private System.Windows.Forms.Button btnVacation;
        private System.Windows.Forms.TextBox txtVacNum;
    }
}