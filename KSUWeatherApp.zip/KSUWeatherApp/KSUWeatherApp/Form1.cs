﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using GenericParsing;

namespace KSUWeatherApp
{
 
    public partial class Form1 : Form
    {
        DataSet tblData = new DataSet();
        string pathToFile;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnImportFile_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ProcessFile("Picknick"));
        }
        public string ProcessFile(string strType)
        {
            string strData;
            string strMessage  ="";
            KSUWeather tblData = new KSUWeather();
            OpenFileDialog ImportDiallog = new OpenFileDialog();
            ImportDiallog.Title = "Open Text File";
            ImportDiallog.Filter = "TXT files|*.txt";
            ImportDiallog.InitialDirectory = @"Y:\KSU Project";
            pathToFile = null;
            while (pathToFile == null)
            {
                if (ImportDiallog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    pathToFile = ImportDiallog.FileName;
                    strData = getFileData(pathToFile);
                    MessageBox.Show(strData);
                    strMessage = "Best day for picknick is";
                }
                else
                {
                    MessageBox.Show("Please select a file");

                }
            }
            return strMessage;
        }
        public string getFileData(string strFilePath)
        {
            string strFileData = "";
            string strLine;
            try
            {
                // Create an instance of StreamReader to read from a file.
                // The using statement also closes the StreamReader.
                using (StreamReader sr = new StreamReader(strFilePath))
                {
                    while ((strLine = sr.ReadLine()) != null && !sr.EndOfStream)
                    {
                        strLine += "\n";
                        strFileData += strLine;
                    }
                }
            }
            catch (Exception e)
            {
                // Let the user know what went wrong.
                MessageBox.Show("The file could not be read:");
                MessageBox.Show(e.Message);
            }
            return strFileData;
        }
    }
}
