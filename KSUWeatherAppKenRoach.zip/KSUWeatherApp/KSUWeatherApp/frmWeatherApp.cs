﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace KSUWeatherApp
{
    public partial class frmWeatherApp : Form
    {
        enum Days { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday };
        DataTable tblKSUWeather = new DataTable("Weather");

        string pathToFile;
        public frmWeatherApp()
        {
            InitializeComponent();
            CreateTable();
        }

        public void ParseMyData(string strData)
        {
            tblKSUWeather.Clear();
            char[] delimiterChars = { ' ', ',', '.', ':', '\t', };
            String pattern = @"\t";
            string[] cols;
            int i;

            using (StringReader reader = new StringReader(strData))
            {
                string line;
                cols = new string[5];
                while ((line = reader.ReadLine()) != null)
                {

                    string[] words = Regex.Split(line, pattern, RegexOptions.IgnorePatternWhitespace);
                    // System.Console.WriteLine($"{words.Length} words in text:");
                    i = 0;
                    foreach (var word in words)
                    {
                        if (!word.Equals("") && !word.Equals(" "))
                        {
                            cols[i] = word;
                            if (i < 5)
                            {
                                ++i;
                            }
                        }
                    }
                    tblKSUWeather.Rows.Add(cols);

                }
            }
        }
        private void btnPicnic_Click(object sender, EventArgs e)
        {
            WeatherRec wr = new WeatherRec();
            string strCOP = "";
            DataTable tbl1 = tblKSUWeather;
            
            string strData = ProcessFile();
            ParseMyData(strData);

            DataRow[] drRows = tbl1.Select("Low >= '21' and High <= '29'", "COP");
            foreach (DataRow drRow in drRows)
            {
                if(strCOP.ToString()=="" || Convert.ToInt32(strCOP.ToString()) > Convert.ToInt32(drRow["COP"].ToString()))
                    wr.date = int.Parse(drRow["date"].ToString());
                    wr.DOW = drRow["DOW"].ToString().Trim();
            }
            MessageBox.Show(rtnDayofWeek(tbl1, wr) + " the " + rtnDate(wr.date) + " day of the month is the best day for a picnic");
        }

        private void btnVacation_Click(object sender, EventArgs e)
        {
            int numDays = 0;
            int lstDate = 0;
            int i = 0;
            if (txtVacNum.Text == "")
            {
                MessageBox.Show("Please enter number of days for your Vaction");
                txtVacNum.Focus();

            }
            else
            {
                numDays = Convert.ToInt32(txtVacNum.Text);
                DataTable tbl1 = tblKSUWeather;
                string strData = ProcessFile();
                ParseMyData(strData);

                DataRow[] drRowsVac = tbl1.Select("Low >= '21' and High <= '29'","date");
                foreach (DataRow drRow in drRowsVac)
                {
                    if(lstDate == 0 )
                    {
                        lstDate = Convert.ToInt32(drRow["date"]);
                        i = 1;
                    }
                    else if ((lstDate + 1) == Convert.ToInt32(drRow["date"]))
                    {
                        lstDate = Convert.ToInt32(drRow["date"]);
                        ++i;
                    }
                    else if(i>0)
                    {
                        numDays = i;
                        lstDate = 0;
                        i = 0;
                    }                  
                }
                if(i>0)
                {
                    numDays = i;
                }
                MessageBox.Show("Best Number of Vacation is  "+ numDays.ToString() + " Days out of " + txtVacNum.Text.ToString());
                lstDate = 0;
                i = 0;
            }
        }
        public void CreateTable()
        {
            tblKSUWeather.Columns.Add("date");
            tblKSUWeather.Columns.Add("DOW");
            tblKSUWeather.Columns.Add("High");
            tblKSUWeather.Columns.Add("Low");
            tblKSUWeather.Columns.Add("COP");

        }
        public string rtnDayofWeek(DataTable ptbl, WeatherRec pRec)
        {
            string strDoW = "";
            string lstDow = "";
            DataRow[] lstRows = ptbl.Select("date='" + (pRec.date - 1) + "'");
            if (lstRows.Count() == 1)
            {
                foreach (DataRow lstRow in lstRows)
                {
                    lstDow = lstRow["dow"].ToString();
                }
            }
            switch (pRec.DOW.ToString())
            {
                case "f":
                    strDoW = "Friday";
                    break;
                case "m":
                    strDoW = "Monday";
                    break;
                case "w":
                    strDoW = "Wednesday";
                    break;
                case "t":
                    if (lstDow.ToString() == "w")
                    {
                        strDoW = "Thursday";
                    }
                    else
                    {
                        strDoW = "Tuesday";
                    }
                    break;
                case "s":
                    if (lstDow.ToString() == "s")
                    {
                        strDoW = "Sunday";
                    }
                    else
                    {
                        strDoW = "Saturday";
                    }
                    break;
            }
            return strDoW.ToString();
        }
        public string rtnDate(int pdate)
        {
            string strEx = "";
            if (pdate == 1 || pdate == 21 || pdate == 31)
            {
                strEx = "st";
            }
            else if (pdate == 2 || pdate == 22)
            {
                strEx = "nd";
            }
            else if (pdate == 3 || pdate == 23)
            {
                strEx = "rd";
            }
            else if ((pdate > 3 && pdate < 21) || (pdate > 23 && pdate < 31))
            {
                strEx = "th";
            }
            return pdate.ToString() + " " + strEx.ToString();

        }

        public string ProcessFile()
        {
            string strData = null;
            OpenFileDialog ImportDiallog = new OpenFileDialog();
            ImportDiallog.Title = "Open Text File";
            ImportDiallog.Filter = "TXT files|*.txt";
            pathToFile = null;
            while (pathToFile == null)
            {
                if (ImportDiallog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    pathToFile = ImportDiallog.FileName;
                    strData = getFileData(pathToFile);
                }
                else
                {
                    MessageBox.Show("Please select a file");

                }
            }
            return strData;
        }
        public string getFileData(string strFilePath)
        {
            string strFileData = "";
            string strLine;
            try
            {
                // Create an instance of StreamReader to read from a file.
                // The using statement also closes the StreamReader.
                using (StreamReader sr = new StreamReader(strFilePath))
                {
                    while ((strLine = sr.ReadLine()) != null && !sr.EndOfStream)
                    {
                        if (!strLine.Contains("DayOfMonth"))
                        {
                            strLine += "\n";
                            strFileData += strLine;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                // Let the user know what went wrong.
                MessageBox.Show("The file could not be read:");
                MessageBox.Show(e.Message);
            }
            return strFileData;
        }

    }

}
public class WeatherRec
{
    public int date { get; set; }
    public string DOW { get; set; }
    public string High { get; set; }
    public string Low { get; set; }
    public string COP { get; set; }
}
